#!/bin/sh

#runlevel: 0/halt 6/Reboot

#1.close all application
#2.Backup All Config and logs
#3.
#4.Umount /dev/shm/fsu
#5.

function BeforeCloseFsu()
{

	if [ ! -d /FsuBackup ];then
		mkdir -p /FsuBackup
	fi
    
    if [ -d /fsu/logs ];then
        cd /fsu/logs
        tar -czvf /FsuBackup/logs.tar.gz *
    fi
    if [ -d /fsu/tmp ];then
        cd /fsu/tmp
        tar -czvf /FsuBackup/tmp.tar.gz *
    fi
    return 0;
}

function StoppingFsu()
{
	pkill Management
	pkill FsuMain
	pkill VpnDial
	pkill WirelessDial
	pkill PortServer
	pkill FeuWrapper
	pkill pppd
	pkill xl2tpd
	pkill watch
	exec /bin/kall &
	fuser -k /fsu
	return 0;
}

function AfterStopFsu()
{
	return 0;
}

BeforeCloseFsu
StoppingFsu
AfterStopFsu
