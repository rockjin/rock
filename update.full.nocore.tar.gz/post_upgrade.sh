echo 'post_upgarde...'
cd /fsu
cp -f kall /bin/
tar xzf etc.tar.gz -C /etc/
if [ -c /dev/ubi0_0 ]; then
    mkdir -f /ubi
    mount -t ubifs /dev/ubi0_0 /ubi
    tar xzf etc.tar.gz -C /ubi/etc
else
    tar xzf etc.tar.gz -C /media/mmcblk0p2/etc/
fi
rm -f /usr/bin/chgip
cp -f version.ini version.old.ini
cp -f apachectl /home/fsu/arm/apache/bin/
rm -f vpninfo.json
rm -f /etc/init.d/save-rtc.sh
rm -f /etc/init.d/hwclock.sh
rm -f /etc/rc0.d/S25save-rtc.sh
rm -f /etc/rc0.d/K20hwclock.sh
rm -f /etc/rc2.d/S20hwclock.sh
rm -f /etc/rc3.d/S20hwclock.sh
rm -f /etc/rc4.d/S20hwclock.sh
rm -f /etc/rc5.d/S20hwclock.sh
rm -f /etc/rc6.d/K20hwclock.sh
rm -f /etc/rc6.d/S25save-rtc.sh
rm -f /etc/init.d/alsa-state
rm -f /etc/init.d/alsa-state
rm -f /etc/rc5.d/S97matrix-gui
rm -f /etc/rcS.d/S39alsa-state
rm -f /etc/rcS.d/S55bootmisc.sh
sync
if [ -a /fsu/uImage ]; then
    cp -f /fsu/uImage /media/mmcblk0p1/
    rm /fsu/uImage
    sync
    cd /fsu
    ./PortServer &
    sleep 10
    ./DevRw -m RebootSys
     reboot
fi






