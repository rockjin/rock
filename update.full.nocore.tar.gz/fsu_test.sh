ls
ifconfig

