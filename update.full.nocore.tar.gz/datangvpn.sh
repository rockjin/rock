pptpsetup --create datangvpn --server 180.163.178.19 --username fsu --password qazwsx,1234 --encrypt --start
