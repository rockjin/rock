ps -ef | grep 'dbus-daemon --fork' | grep -v grep
if [ $? -ne 0 ]; then
  fsu_launch_dbus  
else
  echo '...'
fi
chmod 500 /usr/local/etc/*
chown root:root /var/empty
/usr/local/bin/sshd &
