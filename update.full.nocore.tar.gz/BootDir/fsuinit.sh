#!/bin/sh
#program:
#	This program is going to config the fsu software and start it.
#History:
#
#	Create time:16/11/27	Author:weiyiHou	Modify time:16/08/11	Release version: 0.0


function ConfigFTP()
{
	echo "Config the FTP service";
	if [ ! -L /etc/init.d/startFtp  ];then
		ln -s /fsu/BootDir/startFtp /etc/init.d/startFtp	
	else
		rm /etc/init.d/startFtp	
		ln -s /fsu/BootDir/startFtp /etc/init.d/startFtp
	fi
	chmod +x /etc/init.d/startFtp;	
	/etc/init.d/startFtp
	return 0;
}

function ConfigStm32()
{
    cd /fsu 
	./BeforeFSUStart 
	return 0;
} 
function StartFsuSoftware()
{
    echo "start fsu software";
	Management=`ps aux | grep "Management" | grep -v "grep" | awk '{print $4}' | cut -d / -f 3 `
	if [ "$Management"x = "Management"x  ];then
		/fsu/kall 
		usleep 10
	fi
	cd /fsu/
    ./Management &
	cd ~
	return 0;
}
function StartSsh()
{
     echo "start sshd...";
	/etc/init.d/sshd.sh
	return 0
}
function ConfigDtModule()
{
	echo "1d9f 9c05" > /sys/bus/usb-serial/drivers/option1/new_id
	return 0;
}
function BeforeStartFsu()
{

	cd /fsu/
	
	mkdir -p /dev/shm/logs
	mkdir -p /dev/shm/tmp

	cp -af /fsu/tmp.bk/* /dev/shm/tmp/
	cp -af /fsu/logs.bk/* /dev/shm/logs/
	
	return 0;
}


function AfterStartFsu()
{
	return 0;
}

#Config DtModule
hwclock -s
ConfigDtModule

BeforeStartFsu

#Config StartSSH
StartSsh

#Config the FTP service

ConfigFTP

#Config the stm32 function

ConfigStm32

#Config Fsu application

StartFsuSoftware

#AfterStartFsu Start
AfterStartFsu

exit 0
