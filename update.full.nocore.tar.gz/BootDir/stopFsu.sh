#!/bin/sh

#runlevel: 0/halt 6/Reboot

#1.close all application
#2.Backup All Config and logs
#3.
#4.Umount /dev/shm/fsu
#5.

kall

