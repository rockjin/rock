echo upgrade...
cd /fsu
pkill Management
./Management&
