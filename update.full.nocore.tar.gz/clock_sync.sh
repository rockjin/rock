hwclock -s
ntpdate 216.228.192.69
if [ $? -eq 0 ];then
   echo "sync time sucess!"
   hwclock -w
else
   echo "sync time fail.."
fi

