cd /fsu
pkill FeuWrapper
./FeuWrapper &
