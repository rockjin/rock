<?php
$name = $_POST['loginname'];
$pwd = $_POST['password'];
// var_dump($_POST);

if(($name=="admin")&&($pwd == "admin")){
	echo "true";
}else {
	echo "false";
}

