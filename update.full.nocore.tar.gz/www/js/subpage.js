//获取所有设备信息
function getAlldevice() {
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetAllCellsInfo();",
        // data:cmd,
        dataType: "json",
        async: true,
        success: function(data) {
            for (devs in data) {
                $("#alldevices").append(
                    "<table" + " id=" + data[devs].DeviceId + " class='table'>" +
                    "<caption>" + data[devs].DevName + "  " + data[devs].DeviceId
                    // +"<a href='#' class='refresh'><img src='../images/refresh.png'></a>"
                    +
                    "</caption>" +
                    "<tr><td>信号id</td><td>名称</td><td>值</td><td>单位</td></tr>" +
                    "</table><br>"
                );
                getDevSigle(data[devs].Signals, data[devs].DeviceId);

            }
        }
    })
}

function getDevSigle(data, DeviceId) {
    for (sigs in data) {
        $("#" + DeviceId).append(
            "<tr>" + "<th>" + sigs + "</th>" +
            "<td>" + data[sigs].CellName + "</td>" +
            "<td class='width200'>" + data[sigs].DisplayValue + "</td>" +
            "<td class='width60'>" + data[sigs].Unit + "</td>"
        );
    }
}

function getNetInfo(dsturl, cmd) {
    $.ajax({
        type: "GET",
        url: dsturl,
        data: cmd,
        dataType: "json",
        async: true,
        success: function(data) {
            for (info in data) {
                $("#FsuBasicInfo").append(
                    "<tr>" + "<th>" + data[info].Name + " IP地址:" + "</th>" +
                    "<td>" + data[info].ip0 + "</td>" + "</tr>" + "<tr>" +
                    "<th>" + data[info].Name + "物理地址:" + "</th>" +
                    "<td>" + data[info].Hardware + "</td>" + "</tr>"

                );
            }
        }
    });
}

function getImei() {
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetIMEI();",
        dataType: "text",
        async: true,
        success: function(data) {
            $("#imei").text($.trim(data));
        }
    });
}

/*更新主版本信息*/
function getVersionInfo(dsturl, cmd, ids) {
    $.ajax({
        type: "GET",
        url: dsturl,
        data: cmd,
        dataType: "text",
        async: true,
        success: function(data) {
            // alert(data);
            $("#" + ids).text(data);
        }
    })
}


function trim(str) { //删除左右两端的空格/回车
    　　
    return str.replace(/(^\s*)|(\s*$)/g, "");
}
/*// 获取设备列表
function getDeviceList(durl,cmd){
	var idcmd;
	$.ajax({
		type:"GET",
		url:durl,
		data:cmd,
		dataType:"json",
		async: false,
		success:function(data){
			for(ids in data){
				$("#alldevices").append(
					"<table"+" id="+data[ids].DeviceID+">"
					+"<caption>"+data[ids].DeviceName+"  "+data[ids].DeviceID
					+"<a href='#' class='refresh'><img src='../images/refresh.png'></a>"
					+"</caption>"
					+"<tr><td>信号id</td><td>名称</td><td>值</td><td>单位</td></tr>"
					+
					"</table><br>"
				);
				idcmd = "su:./DevRw%20-m%20ReadSem%20-d%20"+data[ids].DeviceID+"%20-s%209999999999"
				getSinglesTest(durl,idcmd,data[ids].DeviceID);
			}
		}
	});	
}
function getSinglesTest(dsturl,cmd,DeviceID){
	var signals;
	var CellName;
	var Value;
	$.ajax({
		type:"GET",
		url:dsturl,
		data:cmd,
		dataType:"json",
		async: false,
		success:function(data){
			signals = data.Signals;
			for( sigs in signals){
				CellName = signals[sigs].CellName;
				Value = signals[sigs].DisplayValue;
				$("#"+DeviceID).append(
					"<tr>"+"<th>"+sigs+"</th>"
					+"<th>"+CellName+"</th>"
					+"<td>"+Value+"</td>"
					+"<td>"+signals[sigs].Unit+"</td>"
				);			
			}	
		}
	});
}*/