var open = require("open");
open("http://www.baidu.com");