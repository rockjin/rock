//导航菜单已选择的栏目显示绿色。
function funChoosed(ids) {
	$("#side ul li a").css({"background":"#fff","color":"#4444b0"});
	$("#"+"ids").css({"background":"green","color":"#fff"});

}

function gotoPage(page) {
	$("#content").load(page,{'page':' '});
	return false;
}


// +function($){
// 	//点击导航异步加载页面。
// 	var gotoPage = function(page) {
// 		$("#content").load(page,{'page':' '});
// 		return false;
// 	}
// 	// //导航菜单已选择的栏目显示绿色。
// 	// var funChoosed = function(ids) {
// 	// 	$("#side ul li a").css({"background":"#fff","color":"#4444b0"});
// 	// 	$("#"+"ids").css({"background":"green","color":"#fff"});

// 	// }

// }(jQuery);