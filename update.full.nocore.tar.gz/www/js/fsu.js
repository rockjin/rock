/*验证登陆用。后台脚本（后续要改为cgi的程序）验证登陆，
成功返回true字符串，失败返回false字符串*/
function trim(str) { //删除左右两端的空格
    　　
    return str.replace(/(^\s*)|(\s*$)/g, "");
}

function checkuser(name, pwd) {
    var name = name;
    var pwd = pwd;
    var result = "false";
    $.ajax({
        type: "GET",
        url: "/cgi-bin/login",
        async: false,
        data: { loginname: name, password: pwd },
        success: function(msg) {
            result = trim(msg);
        }
    })
    return (result == "true");
}
/*添加cookie*/
function addCookie(name, value, days, path) {
    var name = escape(name);
    var value = escape(value);
    var expires = new Date();
    expires.setTime(expires.getTime() + days * 3600000 * 24);
    var path = (path == "") ? "" : (";path=" + path);
    var _expires = ((typeof days) == "string") ? "" : ";expires=" + expires.toUTCString();
    /*限定参数days只能是数字，如果是字符串，则expires为空*/
    if (days > 0) {
        document.cookie = name + "=" + value + _expires + path;
    } else if (days == 0) {
        document.cookie = name + "=" + value + path; //不设置过期时间，表示关闭浏览器就失效
    } else {
        console.error("days must not be less than zero !");
    }
}

function mainNavControl(ids) {
    $("#side ul li a").css({ "background": "#ffffff", "color": "#4444b0" });
    $("#" + ids).css({ "background": "#213C73", "color": "#ffffff" });
}

/**获取cookie的值，根据cookie的键获取值**/
function getCookieValue(name) {
    var name = escape(name);
    var allcookies = document.cookie;
    name = name + "=";
    var position = allcookies.indexOf(name); //寻找name的位置
    if (position != -1) { /*如果为-1则没找到*/
        var start = position + name.length;
        var end = allcookies.indexOf(";", start); //从cookie开始的位置找第一个分号;
        if (end == -1) { end = allcookies.length; } //如果end值为-1说明cookie列表里只有一个cookie  
        var value = allcookies.substring(start, end);
        return (value);
    } else {
        return "";
    }

}
/*删除cookie，将有效时间设置为0*/
function deleteCookie(name, path) {
    var name = escape(name);
    var expires = new Date(0);
    path = (path == "") ? "" : (";path=" + path);
    document.cookie = name + "=" + ";expires=" + expires.toUTCString() + path;
}

//绘制信号强度
function setSigVal(value) {
    var c = document.getElementById("sigVal");
    var cxt = c.getContext("2d");
    c.height = c.height;
    cxt.save();
    cxt.strokeStyle = "#326BA9";
    cxt.fillStyle = "#326BA9";
    cxt.translate(5, 50);
    cxt.scale(1, -1);
    for (var i = 0; i < 5; i++) {
        cxt.strokeRect(i * 8 + i * 3, 0, 8, 8 + i * 8);
    }
    if (value >= 0) {
        for (var i = 0; i < value; i++) {
            cxt.fillRect(i * 8 + i * 3, 0, 8, 8 + i * 8);
        }
    } else {
        cxt.scale(1, -1);
        cxt.font = "20px Arial";
        cxt.fillStyle = "red";
        cxt.fillText("X", -0, -18);
    }
    cxt.restore();

}
//获取信号强度
function getSigVal() {
    var sigval = -1;
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetRssi()",
        dataType: "text",
        async: false,
        success: function(data) {
            // alert(data.slice(0,2));		
            var sig = parseInt(data);
            var c = document.getElementById("sigVal");
            c.setAttribute("Title", sig + "dBm");
            sigval = (sig + 113) * 5.0 / (113.0 - 51);
        }
    });
    return sigval;
}
//获取运营商信息
function getCurrentServiceName() {
    var ServiceName = "无服务";
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetServiceName()",
        dataType: "text",
        async: true,
        success: function(data) {
            ServiceName = "运营商:" + data;
            $("#Mobile-Network-Operator").html(ServiceName)
        }
    });
}
//获取网络制式
function getNetworkType() {
    var workType = "无信号";
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetNetworkType()",
        dataType: "text",
        async: true,
        success: function(data) {
            workType = "网络制式:" + data;
            $("#Network-type").html(workType);
        }
    });
}
//获取软件版本信息
function getSoftVersionInfo() {
    var SoftVersion = "获取中……";
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetSoftwareVersion()",
        dataType: "text",
        async: true,
        success: function(data) {
            SoftVersion = "软件版本:" + data;
            $("#Software-version").html(SoftVersion);
        }
    });
}
//获取硬件版本信息
function getHardVersionInfo() {
    var HardVersion = "获取中……";
    $.ajax({
        type: "GET",
        url: "/cgi-bin/ExecuteCmd?script:fsu.GetHardwareVersion()",
        dataType: "text",
        async: true,
        success: function(data) {
            HardVersion = "硬件版本:" + data;
            $("#Hardware-version").html(HardVersion);
        }
    });
}
String.prototype.format = function(args) {
        var result = this;
        if (arguments.length > 0) {
            if (arguments.length == 1 && typeof(args) == "object") {
                for (var key in args) {
                    if (args[key] != undefined) {
                        var reg = new RegExp("({" + key + "})", "g");
                        result = result.replace(reg, args[key]);
                    }
                }
            } else {
                for (var i = 0; i < arguments.length; i++) {
                    if (arguments[i] != undefined) {
                        var reg = new RegExp("({)" + i + "(})", "g");
                        result = result.replace(reg, arguments[i]);
                    }
                }
            }
        }
        return result;
    }
    //获取gps信息
function getGpsInfo() {
    var gpsinfo = "GPS信息获取中……"
    $.ajax({
        type: "GET",
        url: "cgi-bin/ExecuteCmd?script:fsu.GetGPSAddress()",
        dataType: "text",
        async: true,
        success: function(data) {
            gpsinfo = data;
            $("#gpsinfo").html(data);
        }
    });
}
//获取设备sn
function getSn() {
    $.ajax({
        type: "GET",
        url: "cgi-bin/ExecuteCmd?script:fsu.GetSn()",
        dataType: "text",
        async: true,
        success: function(data) {
            sn = "设备序列号:" + "<br>" + data;
            $(".sn").html(sn);
        }
    })
}