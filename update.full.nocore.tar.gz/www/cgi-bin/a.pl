print('Content-type: text/plain');
print("\n\n");
print("update finished.\n");
