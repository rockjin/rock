echo 'pre_upgarde...'
cd /fsu
cp -f version.ini version.old.ini
if [ -a /dev/shm/temp/Management ]; then
    cp -f /dev/shm/temp/Management /fsu/
fi





