#!/bin/sh
#program:
#	This program is going to config the fsu software and start it.
#History:
#
#	Create time:16/11/27	Author:weiyiHou	Modify time:16/08/11	Release version: 0.0

export LD_LIBRARY_PATH=/usr/lib:/opt/qt5.5.1/lib:$LD_LIBRARY_PAT
JAVA_HOME=/jre
PATH=$JAVA_HOME/bin:$PATH
CLASSPATH=.:$JAVA_HOME/lib/rt.jar:$JAVA_HOME/lib
export JAVA_HOME
export PATH
export CLASSPATH


function ConfigFTP()
{
	/bin/kall
	sleep 1
	echo "Config the FTP service";
	if [ ! -L /etc/init.d/startFtp  ];then
		ln -s /etc/fsu/BootDir/startFtp /etc/init.d/startFtp	
	else
		rm /etc/init.d/startFtp	
		ln -s /etc/fsu/BootDir/startFtp /etc/init.d/startFtp
	fi
	chmod +x /etc/init.d/startFtp;	
	exec /etc/init.d/startFtp & 
	return 0;
}

function ConfigStm32()
{
	echo "Config the STM32 function";
	if [ ! -L /etc/init.d/resetStm32 ];then
		ln -s /etc/fsu/BootDir/resetStm32 /etc/init.d/resetStm32
	else
		rm /etc/init.d/resetStm32
		ln -s /etc/fsu/BootDir/resetStm32 /etc/init.d/resetStm32
	fi
	chmod +x /etc/init.d/resetStm32
	exec /etc/init.d/resetStm32 &
	return 0;
} 
function StartFsuSoftware()
{
	Management=`ps aux | grep "Management" | grep -v "grep" | awk '{print $4}' | cut -d / -f 3 `
	if [ "$Management"x = "Management"x  ];then
		/fsu/kall 
		usleep 10
	fi
	cd /fsu/
	sleep 10
	exec ./Management &
	cd ~
	return 0;
}
function StartSsh()
{
	exec /etc/init.d/sshd.sh &
	return 0
}
function ConfigDtModule()
{
	echo "1d9f 9c05" > /sys/bus/usb-serial/drivers/option1/new_id
	return 0;
}
function BeforeStartFsu()
{
	switch=49
	if [ ! -d /sys/class/gpio/gpio"$switch" ];then
		echo "$switch" > /sys/class/gpio/export
	fi	
	echo "out" > /sys/class/gpio/gpio"$switch"/direction
	sleep 1
	echo 0 > /sys/class/gpio/gpio"$switch"/value
	sleep 1
	echo 1 > /sys/class/gpio/gpio"$switch"/value
	
	if [ ! -d /fsu ];then
		mkdir /fsu
	fi

	if [ ! -d /dev/shm/fsu ];then
		mkdir -p /dev/shm/fsu
	fi

	mount /dev/shm/fsu /fsu 
	cd /fsu/	
	if [ ! -d /FsuBackup ];then
		mkdir -p /FsuBackup
	fi
	
	if [ ! -d /fsu/tmp ];then
		mkdir -p /fsu/tmp 
	fi
	
	if [ ! -d /fsu/logs ];then
		mkdir -p /fsu/logs
	fi
	
	if [ -f /FsuBackup/fsu.tar.gz ];then
		tar xzvpf /FsuBackup/fsu.tar.gz -C ./
	fi
	
	if [ -f /FsuBackup/xml.tar.gz ];then
		tar xzvpf /FsuBackup/xml.tar.gz -C ./
	fi
	
	if [ -f /FsuBackup/feu.tar.gz ];then
		tar xzvf /FsuBackup/feu.tar.gz -C ./
	fi
	
	if [ -f /FsuBackup/tmp.tar.gz ];then
		tar xzvf /FsuBackup/tmp.tar.gz -C ./tmp/
	fi
	
	if [ -f /FsuBackup/logs.tar.gz ];then
		tar xzvf /FsuBackup/logs.tar.gz -C ./logs/
	fi
		
	cd ~
	
	return 0;
}


function AfterStartFsu()
{
	chmod +x /FsuBackup/*.tar.gz
	if [ ! -L /etc/init.d/stopFsu ];then
		ln -s /etc/fsu/BootDir/stopFsu.sh /etc/init.d/stopFsu
		cd ~
	fi
	if [ ! -f  /fsu/tmp/default ];then
		touch /fsu/tmp/default
	fi
	if [ ! -f /fsu/logs/default ];then
		touch /fsu/logs/default
	fi
	if [ ! -f /fsu/feu.log.default ];then
		touch feu.log.default
	fi
	return 0;
}

#Config DtModule
ConfigDtModule

BeforeStartFsu

#Config StartSSH
StartSsh

/home/fsu/arm/apache/bin/apachectl start

#Config the FTP service

ConfigFTP

#Config the stm32 function

ConfigStm32

#Config Fsu application

StartFsuSoftware

#AfterStartFsu Start
AfterStartFsu

exit 0
